// pages/person/person.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    aimgurl: "", // //临时图片的路径
    countIndex: 1, // 可选图片剩余的数量
    imageData: [], // 所选上传的图片数据
    //接收服务器传来的参数包括时间工作方式等
  },



  /*图片浏览及上传 */
  browse: function(e) {
    let that = this;
    wx.showActionSheet({
      itemList: ['从相册中选择图片', '拍照'],
      itemColor: "#CED63A",
      success: function(res) {
        if (!res.cancel) {
          if (res.tapIndex == 0) {
            that.chooseWxImage('album');
          } else if (res.tapIndex == 1) {
            that.chooseWxImage('camera');
          }
        }
      }
    })
  },

  /*打开相册、相机 */
  chooseWxImage: function(type) {
    let that = this;
    wx.chooseImage({
      count: that.data.countIndex,
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: function(res) {
        // 选择图片后的完成确认操作
        that.setData({
          aimgurl: res.tempFilePaths
        });
        console.log(that.data.aimgurl);
      }
    })
  },



  // 图片上传至服务器
// upLoadImgFun: function(tempFilePathsData) {
//   let that = this;
//   let orderCommentMaterial = []; // 每次选择添加的图片并上传到服务器后的图片信息
//   tempFilePathsData.forEach((item, index) => {
//     wx.uploadFile({
//       url: HTTP.uploadFileUrl(), // 上传服务器的后台请求接口地址
//       filePath: item, // 要上传的图片数据对象
//       name: 'file', // 上传类型
//       header: {
//         'content-Type': 'multipart/form-data' // 此处加上，用form表单的格式传
//       },
//       // 要携带的参数
//       formData: {
//         "systemCode": "aaa",
//         "belongCode": "cccccc",
//         "belongID": "123456"
//       },
//       success(res) {
//         console.log(res);
//       },
//       fail(err) {
//         console.log(err);
//       },
//       complete(all) {
//         console.log(all);
//       }
//     });
//   });
// }
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.showToast({
      title: '欢迎拍照咨询',
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})